package com.java.learn;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MapExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println("------HashMap Example-------");		
	HashMap<Integer,String> hMap = new HashMap<Integer,String>();
	
	hMap.put(new Integer(1),"pradeep");
	hMap.put(new Integer(5),"Deepali");
	hMap.put(new Integer(3),"Ashish");
	hMap.put(new Integer(3),"Ashish");
	System.out.println("Hash Map "+hMap);
	
	// Get a set of the entries
    Set set = hMap.entrySet();
    
    // Get an iterator
    Iterator i = set.iterator();
    
    // Display elements
    while(i.hasNext()) {
       Map.Entry me = (Map.Entry)i.next();
       System.out.print(me.getKey() + ": ");
       System.out.println(me.getValue());
       
       System.out.println("------------");
       //System.out.println(me.getKey() + ": "+hMap.get(me.getKey()));
    }
    System.out.println();
    
    // Deposit 1000 into Zara's account
  /*  double balance = ((Double)hMap.get("Zara")).doubleValue();
    hMap.put("Zara", new Double(balance + 1000));
    System.out.println("Zara's new balance: " + hm.get("Zara"));*/
    
    System.out.println("------Linked HashMap Example-------");	
    LinkedHashMap lMap = new LinkedHashMap();
    
    lMap.put("Pradeep", 32);
    lMap.put("Ramya", 25);
    lMap.put("Sweety", 1);
    System.out.println("Linked Hash Map"+lMap);
    
    System.out.println("------HashMap Example-------");		
	IdentityHashMap<Integer,String> iMap = new IdentityHashMap<Integer,String>();
	iMap.put(new Integer(1),"pradeep");
	iMap.put(new Integer(5),"Deepali");
	iMap.put(new Integer(3),"Ashish");
	iMap.put(new Integer(3),"Ramya");
	System.out.println("Identity Hash Map "+iMap);
    
    
	}
	

}
