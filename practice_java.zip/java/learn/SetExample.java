package com.java.learn;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.*;
public class SetExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  System.out.println("----Set exapmle----");
		    Set<String> set = new HashSet<String>();
		    
		    set.add("Pradeep");
		    set.add("Pradeep");
		    set.add("ashish");
		    set.add("deepali");
		    set.add("friend");
		    
		    System.out.println(set);
		    Iterator setIterator = set.iterator();
		    while(setIterator.hasNext())
		    {
		    	 String var= (String) setIterator.next();
		    	 if(var.equals("friend"))
		    		 setIterator.remove();
		    	 else
		    		 System.out.println(var);
		    }
		    
		    String[] setArray = (String[]) set.toArray(new String [set.size()]); 
		    // String[] setArray = new String[set.size()];
		    // setArray = set.toArray(setArray);
		    set.remove("Pradeep");
		    System.out.println(set);
		     for(int i = 0; i<setArray.length;i++)
		    	 System.out.println(setArray[i]);
		     System.out.println("-----Linked hastSet---------");
		     LinkedHashSet<String> linkHashset = new LinkedHashSet<String>();
		     linkHashset.add("Pradeep");
		     linkHashset.add("Pradeep");
		     linkHashset.add("ashish");
		     linkHashset.add("deepali");
		     linkHashset.add("friend");
			    
		     System.out.println(linkHashset);
		     
		     Iterator iteratorHashset = linkHashset.iterator();
		     while(iteratorHashset.hasNext())
		    	 System.out.println(iteratorHashset.next());
		     
		     System.out.println("--------Sorted Set Example------");
		     
		     SortedSet<String> sset= new TreeSet<String>();
		     
		     sset.add("Pradeep");
		     sset.add("Deepali");
		     sset.add("Ashish");
		     sset.add("Friendd");
		     
		     System.out.println(sset);
		     
		     Iterator iSortedSet= sset.iterator();
		     while(iSortedSet.hasNext())
		     {
		    	 System.out.println(iSortedSet.next());
		     }
		     
		     System.out.println("--------Tree Set Example------");
		     TreeSet tSet= new TreeSet(new MyComparator());
		     tSet.add(6);
		     tSet.add(10);
		     tSet.add(15);
		     tSet.add(1);
		     tSet.add(2);
		     System.out.println(tSet);
	 }
	
}
class MyComparator implements Comparator<Object> {
    public int compare(Object s1, Object s2) {
    	Integer i1 = (Integer)s1;
    	Integer i2 = (Integer)s2;
    	if(i1<i2)
    		
    		return -1;
    	else
    		 return +1;
       // return i1.compareTo(i2);
    }
}
