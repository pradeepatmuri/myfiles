package com.java.learn;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.lang.StringUtils;

public class FileReadExample {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream fis = new FileInputStream("C://Users//382548//Desktop//settings.xml");
		BufferedReader br = new BufferedReader(new InputStreamReader(fis));
		String strLine;
		// Read File Line By Line
		while ((strLine = br.readLine()) != null) {
		String fileName = StringUtils.substringBetween(strLine,
		"<FileName>", "</FileName>");
		// Print the content on the console
		System.out.println(fileName);
		}
		br.close();
		
		
	}

}
