package com.java.learn;

import java.util.Random;

public class RandomExample {
	
	public static void main(String a[]){
	Random random = new Random();
	
	System.out.println("float "+random.nextFloat());
	System.out.println("int "+random.nextInt(6));
	System.out.println("long "+random.nextLong());
	System.out.println("double "+random.nextDouble());
	
	System.out.println("math random "+Math.random());
}	
	}
