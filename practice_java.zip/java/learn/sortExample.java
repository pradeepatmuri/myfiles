package com.java.learn;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class sortExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer[] array = {1,2,3,4};
		Arrays.sort(array,  (e1,e2)-> e2.compareTo(e1)  );
		System.out.println(Arrays.toString(array));
		Integer[] array1 = {100,200,300,400};
		List<Integer> list = Arrays.asList(array1);
		Collections.sort(list,Collections.reverseOrder());
		System.out.println(list);
		
	}

}
