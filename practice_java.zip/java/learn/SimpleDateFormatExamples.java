package com.java.learn;
 
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
 
/**
 *
 * @author Pankaj
 * This class demonstrates different scenarios and usage of SimpleDateFormat class
 *
 */
public class SimpleDateFormatExamples {
 
    public static void main(String[] args) throws ParseException {
 
        SimpleDateFormat sdf = new SimpleDateFormat();
        Date date = new Date();
 
        //Simple Date Formatting Examples
        sdf.applyPattern("MM/dd/yyyy");
        System.out.println("MM/dd/yyyy Pattern: "+sdf.format(date));
 
        //Date format with extra strings
        sdf.applyPattern("hh:mm 'o'' Clock on' MMMM dd yyyy");
        System.out.println("hh:mm 'o'' Clock on' MMMM dd yyyy Pattern: "+sdf.format(date));
 
        //Date Formatting with Locale settings
        sdf = new SimpleDateFormat("dd MMMM yyyy zzzz G", Locale.GERMAN);
        System.out.println("dd MMMM yyyy zzzz G Pattern: "+sdf.format(date));
 
        //Parsing String to Date Object
        System.out.println("Native Date Format:"+date.toString());
        String dateToParse = date.toString();
        sdf = new SimpleDateFormat("E MMM dd HH:mm:ss zzz yyyy", Locale.ROOT);
        System.out.println("Parsed Date as String:"+sdf.parse(dateToParse).toString());
 
        //using Timezone in parsing
        sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        Date parsedDate = sdf.parse("23-03-1984");
        System.out.println("Date with Default TimeZone: "+parsedDate);
        sdf.setTimeZone(TimeZone.getTimeZone("EST"));
        parsedDate = sdf.parse("23-03-1984");
        System.out.println("Date with IST TimeZone: "+parsedDate);
 
        //Strict Parsing
        /**
         * By default, SimpleDateFormat parsing is very lenient. It tries to give correct answer rather
         * than throwing Exception. What it means is that if the String to parse is "32-May-2011" it will
         * treat it as 31-May-2011 + one day and gives output of 01 Jun 2011
         */
        sdf = new SimpleDateFormat("dd-MM-yyyy", Locale.ENGLISH);
        System.out.println("Lenient Parsing example: "+sdf.parse("32-05-2011"));
        //Making the Parsing Strict
        sdf.setLenient(false);
        // Below line should throw ParseException
        System.out.println("Lenient Parsing example: "+sdf.parse("32-05-2011"));
 
    }
 
}