package com.java.learn;
public class Child extends Parent{

	public int salary;
}