package com.java.learn;

import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Set;

public class Enums {

	/**
	 * @param args
	 */
	enum Direction
	{
		EAST(0){
			@Override
			public void shout(){
				System.out.println("This is East");
			}
		
		}
		,WEST(180){
			@Override
			public void shout(){
				System.out.println("This is West");
			}
		}
		,NORTH(90){
			@Override
			public void shout(){
				System.out.println("This is North");
			}
		}
		,SOUTH(270){
			@Override
			public void shout(){
				System.out.println("This is South");
			}
		};
		public abstract void shout();
		private Direction(int angle){
			this.angle=angle;
		}
		
		private int angle;
		
		public int getAngle() {
				return angle;
			}
		public void setAngle(int angle) {
			this.angle = angle;
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println(Direction.EAST.getAngle());
		System.out.println(Direction.WEST.getAngle());
		System.out.println(Direction.NORTH.getAngle());
		System.out.println(Direction.SOUTH.getAngle());
		
		Direction[] dirArray = Direction.values();
		for (Direction d: dirArray)
		{
			System.out.println(d+"----"+d.getAngle());
		}
		
		Direction dir = Direction.SOUTH;
		System.out.println("methods of Enum"+dir.getAngle());
		
		Direction dirs = Enum.valueOf(Direction.class, "EAST");
		System.out.println(dirs +"" +dirs.getAngle());
		
		EnumSet<Direction> enumSet = EnumSet.allOf(Direction.class);
		for(Direction dirset : enumSet){
			System.out.println("Using EnumSet, angle = "+dirset.getAngle());
		}
		
		EnumMap<Direction,String> enumMap = new EnumMap<Direction,String>(Direction.class);
		enumMap.put(Direction.EAST, "Thread is East");
		enumMap.put(Direction.WEST, "Thread is west");
		enumMap.put(Direction.SOUTH, "Thread is south");
		enumMap.put(Direction.NORTH, "Thread is north");
		
		Set<Direction> enumSet1 = enumMap.keySet();
		for(Direction enum1: enumSet1)
		{	
			System.out.println(enum1+"---"+enumMap.get(enum1));
			System.out.println(enum1.getAngle() );
			enum1.shout();
		}
		
	}

}
