package com.java.learn;

import java.util.HashSet;
import java.util.Set;
class Emp {
	private String name;
	private int id;

	public Emp(int i, String n) {
		this.setId(i);
		this.setName(n);
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString(){
		return "{"+getId()+","+getName()+"}";
	}
	@Override
	public boolean equals(Object obj){
		if(obj == null || !(obj instanceof Emp)) return false;
		Emp e= (Emp)obj;
		if(e.getId() == this.getId() && this.getName().equals(e.getName())) return true;
		return false;
	}
	@Override
	public int hashCode(){
		return getId();
	}
	}
public class EmployeeSetExample {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Set<Emp>  emps = new HashSet<Emp>();
		
		emps.add(new Emp(1,"Pradeep"));
		emps.add(new Emp(2,"Deepali"));
		emps.add(new Emp(3,"Ashish"));
		emps.add(new Emp(3,"Ashish"));
		System.out.println(emps);
	}
	
}
