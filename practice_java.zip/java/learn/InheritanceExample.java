package com.java.learn;

public class InheritanceExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child p = new Child();
		p.name = "test";
		System.out.println(p.name+p.salary);
	}

}
