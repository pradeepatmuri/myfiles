package com.java.learn;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesExample {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Properties p =new Properties();
		FileInputStream fis =new FileInputStream("C:\\Users\\382548\\Desktop\\mu\\properties\\connection.properties");
		p.load(fis);
		String s = p.getProperty("CLASS_NAME");
		System.out.println(s);
		p.setProperty("DataBase","Teradata");
		FileOutputStream fos = new FileOutputStream("C:\\Users\\382548\\Desktop\\mu\\properties\\connection.properties");
		p.store(fos, "updated by Pradeep");
	}

}
