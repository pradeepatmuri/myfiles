package com.java.learn;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Permutation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String temp="ABAC";
		System.out.println("---Permutration finder"+permutationFinder(temp));
		System.out.println("---Permutration finder"+permutationFinderwithoutrecurrsion(temp));
	}

	private static Set<String> permutationFinderwithoutrecurrsion(String temp) {
		Set<String> genString = new HashSet<>();
		int size = temp.length();
		int i,j;
		if (temp == null )
			return null;
		else if (temp.length()==0){
			genString.add("");return genString;}
		else{
			for(i=0;i<size;i++)
			{	
				char firstPart =temp.charAt(i);String secPart="";
				if(i==0)
					secPart =temp.substring(i+1,size);
				else if(i == (size-1) )
					secPart =temp.substring(0,size-1);
				else
					secPart = temp.substring(0,i) + temp.substring(i+1,size);
				int secpartsize=secPart.length();
				genString.add(firstPart+secPart);
				genString.add(secPart+firstPart);
				for(j=0;j<=secpartsize;j++)
				{	
					System.out.println("--"+secPart.substring(0,j)+firstPart+secPart.substring(j,secpartsize));
					genString.add(secPart.substring(0,j)+firstPart+secPart.substring(j,secpartsize));
				}
				
			}
		}
		return genString;
	}

	private static Set<String> permutationFinder(String temp) {
		Set<String> genString = new HashSet<>();
		if (temp == null )
			return null;
		else if (temp.length()==0){
			genString.add("");return genString;}
		else{
			char firstChar=temp.charAt(0);
			String rem=temp.substring(1);
			Set<String> words = permutationFinder(rem);
	        for (String strNew : words) {
	            for (int i = 0;i<=strNew.length();i++){
	            	genString.add(charInsert(strNew, firstChar, i));
	            }
	        }
	        return genString;
		}
		
	}

	private static String charInsert(String str, char firstChar, int j) {
		// TODO Auto-generated method stub
		String begin = str.substring(0, j);
        String end = str.substring(j);
        return begin + firstChar + end; 
	}

}
