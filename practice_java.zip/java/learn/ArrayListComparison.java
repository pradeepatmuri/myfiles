package com.java.learn;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ArrayListComparison {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		      // ArrayList 
		      List a1 = new ArrayList();
		      a1.add("likhil");
		      a1.add("likhil");
		      a1.add("Mahnaz");
		      a1.add("Ayan");
		      a1.add("Ayan");
		      a1.add("likhil");
		      System.out.println("a1" + a1);
		      //a1.remove("Zara");
		      a1.remove(0);
		      System.out.println(a1.lastIndexOf("likhil"));
		      System.out.println(a1.indexOf("likhil"));
		      System.out.println(" ArrayList Elements");
		      System.out.println("\t a1" + a1);
		      
		      ArrayList a2 = new ArrayList();
		      a2.add("Ayan");
		      a2.add("Ayan");
		     /* a2.add("Lakshmi");
		      a2.add("satya");
		      a2.add("ayan");*/
		      System.out.println("second  ArrayList Elements");
		      System.out.print("\t a2" + a2);
		      //a2.clear();
		      if(a2.equals(a1))
		      {
		    	  System.out.println("true");
		      }
		      else
		      {  System.out.println("false"); }
		      
		      if(a2.contains("Ayan"))
		      {
		    	  System.out.println("yes");
		      }
		      else
		      {
		    	  System.out.println("no");
		      }
		      if(a2.containsAll(a1))
		      {
		    	  System.out.println("contained all");
		      }
		      else{
		    	  System.out.println("not all");
		      }
		      System.out.println("second  ArrayList Elements");
		      System.out.println("\t a2" + a2);
		      System.out.println("--"+a1);
		      a1.retainAll(a2);
		      System.out.println("--"+a1);
		      System.out.println(a1.size());
		      String a[]= new String[a1.size()];
		    	  a=(String[]) a1.toArray(a);
		    	  System.out.println(a);
		      /* // LinkedList
		      List l1 = new LinkedList();
		      l1.add("Zara");
		      l1.add("Mahnaz");
		      l1.add("Ayan");
		      l1.add("Ayan");
		      System.out.println();
		      System.out.println(" LinkedList Elements");
		      System.out.print("\t" + l1);
			
				
		     // HashSet
		      Set s1 = new HashSet(); 
		      s1.add("Zara");
		      
		      s1.add("Ayan");
		      s1.add("Ayan");
		      s1.add("Mahnaz");
		      System.out.println();
		      System.out.println(" Set Elements");
		      System.out.print("\t" + s1);

		      // HashMap
		      Map m1 = new HashMap(); 
		      m1.put("Zara", "8");
		      m1.put("Mahnaz", "31");
		      
		      m1.put("Ayan", "12");
		      m1.put("Daisy", "14");
		      m1.put("Daisy", "5");
		      System.out.println();
		      System.out.println(" Map Elements");
		      System.out.print("\t" + m1);
*/		   


	}

}
