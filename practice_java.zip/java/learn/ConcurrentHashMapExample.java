package com.java.learn;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="";
		Map <String,String> mychMap = new ConcurrentHashMap<>(); 
		mychMap.put("Pradeep","1");
		mychMap.put("balu","1");
		mychMap.put("raju","1");
		mychMap.put("siva","1");
		mychMap.put("ram","1");
		System.out.println("ConcurrentHashMap before iterator: "+mychMap);
		Iterator itr = mychMap.keySet().iterator();
		while(itr.hasNext()){
			str = (String) itr.next();
			if(str.equalsIgnoreCase("pradeep"))
				mychMap.put("PradeepNew", "1new");
			
		}
		
		System.out.println("ConcurrentHashMap after iterator: "+mychMap);
		
		Map <String,String> myMap = new HashMap<>(); 
		myMap.put("Pradeep","1");
		myMap.put("balu","1");
		myMap.put("raju","1");
		myMap.put("siva","1");
		myMap.put("ram","1");
		System.out.println("ConcurrentHashMap before iterator: "+myMap);
		Iterator itr1 = myMap.keySet().iterator();
		while(itr1.hasNext()){
			str = (String) itr1.next();
			System.out.println(str);
			if(str.equalsIgnoreCase("pradeep")){
				myMap.put("Pradeep", "1new");
				//break;
			}
			
		}
		
		System.out.println("ConcurrentHashMap after iterator: "+myMap);
	}

}
