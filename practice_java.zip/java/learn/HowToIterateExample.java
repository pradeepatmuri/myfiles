package com.java.learn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TreeSet;

public class HowToIterateExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("----------Iteration of List---");
		List <String> myList = new ArrayList<String> ();
		myList.add("Pradeep");
		myList.add("Ramya");
		myList.add("Baby");
		
		System.out.println(myList.size()+"---"+myList);
		System.out.println("First Technique");
		for(int i=0; i<myList.size();i++)
			System.out.println(myList.get(i));
		System.out.println("-----------------");
		System.out.println("Second Technique");
		Iterator i = myList.iterator();
		while(i.hasNext())
			System.out.println(i.next());
		System.out.println("-----------------");
		System.out.println("Third Technique");
		for(String myListStr: myList)
			System.out.println(myListStr);
		System.out.println("-----------------");
		System.out.println("Fouth technique");
		
		ListIterator listIterator = myList.listIterator();
		
		while(listIterator.hasNext())
			System.out.println(listIterator.next());
		while(listIterator.hasPrevious())
			System.out.println(listIterator.previous());
		System.out.println("-----------------");
		System.out.println("Fifth technique");
		for(Iterator iter = myList.iterator();iter.hasNext();)
			System.out.println(iter.next());
		System.out.println("-----------------");
		System.out.println("sixth technique");
		for(Iterator<String> iter = myList.iterator();iter.hasNext();)
			System.out.println(iter.next());
		System.out.println("-----------------");
		
		System.out.println("Seventh technique");
		myList.forEach(listVal-> System.out.println(listVal));
		System.out.println("-----------------");
		
		Map m=new HashMap();
		m.put(1, "Pradeep");
		m.put(2, "Ramya");
		m.put(3, "Baby");
		
		System.out.println(m.size()+"---"+m);
		System.out.println("First technique");
		Iterator itrMap = m.entrySet().iterator();
		while(itrMap.hasNext()){
			Map.Entry entry = (Map.Entry) itrMap.next();
		    Integer key = (Integer)entry.getKey();
		    String value = (String)entry.getValue();
		    System.out.println("Key = " + key + ", Value = " + value);
		}
		System.out.println("-----------------");
		System.out.println("Second technique");
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(1, "Pradeep");
		map.put(2, "Ramya");
		map.put(3, "Baby");
		System.out.println(map.entrySet());
		Set<Entry<Integer,String>> entrySet = map.entrySet();
		Iterator<Entry<Integer,String>> itrEntrySet  =entrySet.iterator();
		     while (itrEntrySet.hasNext()) {
		     Entry<Integer, String> entry = (Entry<Integer,String>)itrEntrySet.next();
		     System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}
		System.out.println("-----------------");
		System.out.println("Third technique");
		for(Map.Entry<Integer, String> myMapEntry: map.entrySet())
			System.out.println(myMapEntry.getKey()+"--"+myMapEntry.getValue());
		System.out.println("-----------------");
		System.out.println("fourth technique");
		for(Integer key: map.keySet())
			System.out.println(key+"--"+map.get(key));
		for(String value: map.values())
			System.out.println(value);
		System.out.println("-----------------");
		System.out.println("FIFTH technique");
		map.forEach( (k,v) -> System.out.println("Key: " + k + ": Value: " + v));
		System.out.println("-------Hashset----------");
		
		
		Set<String> s  =new HashSet<String>();
		s.add("Pradeep");
		s.add("Ramya");
		s.add("baby");
		System.out.println(s.size()+"---"+s);
		System.out.println("First Technique");
		Iterator<String>  iSet =s.iterator();
		while(iSet.hasNext())
			System.out.println(iSet.next());
		System.out.println("-----------------");
		System.out.println("Second Technique");
		for(String iSetStr:s)
			System.out.println(iSetStr);
		System.out.println("-----------------");
		System.out.println("Third Technique");
		s.forEach(val ->System.out.println(val));
		System.out.println("fourth Technique");
		s.forEach(System.out::println);
		System.out.println("-----------------");

		
		 List<String> gamesList = new ArrayList<String>();  
	        gamesList.add("Football");  
	        gamesList.add("Cricket");  
	        gamesList.add("Chess");  
	        gamesList.add("Hocky");  
	        System.out.println("------------Iterating by passing lambda expression--------------");  
	        gamesList.forEach(games -> System.out.println(games));  
	        
	      SortedSet<String> mySet = new TreeSet<>( (i1,i2)-> i2.compareTo(i1));    
	      mySet.add("Football");  
	      mySet.add("Cricket");  
	      mySet.add("Chess");  
	      mySet.add("Hocky");
	      mySet.forEach(set1 -> System.out.println(set1)); 

	      SortedSet<Integer> intSet = new TreeSet<>();
	      intSet.addAll(Arrays.asList(7,2,1,4,6,5));
	      SortedSet<Integer> mySubSet = intSet.subSet(0, 4);
	      intSet.forEach(set1 -> System.out.print(" "+set1)); 
	      System.out.println();
	      mySubSet.forEach(set1 -> System.out.print(" "+set1)); 
	      intSet.add(10);
	      
	      System.out.println(intSet+"   "+mySubSet);
	      
	      
	      List<String> names = new ArrayList<>();
			names.add("Java"); names.add("PHP");names.add("SQL");names.add("Angular 2");
			
			List<String> first2Names = names.subList(0, 2);
			
			System.out.println(names +" , "+first2Names);
			
			names.set(1, "JavaScript");
			//check the output below.
			System.out.println(names +" , "+first2Names);
			
			//Let's modify the list size and get ConcurrentModificationException
			first2Names.add("NodeJS");
			System.out.println(names +" , "+first2Names); //this line throws exception

	}

}
