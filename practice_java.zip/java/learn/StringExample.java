package com.java.learn;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s3 = "JournalDev";
		int start = 1;
		char end = 5;
		System.out.println(start + end);
		System.out.println(s3.substring(start, end));
		
		System.out.println("----");
		HashSet shortSet = new HashSet();
		for (short i = 0; i < 100; i++) {
			shortSet.add(i);
			short b=1;
			shortSet.remove(i -b);
		}
		System.out.println(shortSet.size());
		
		System.out.println("----");
		Integer a=2;
		Integer b=3;
		add(2,3);
		
			int x = 10-10*10;
		
		System.out.println(x);
		System.out.println("-----");
		try {
			throw new IOException("Hello");
		}catch(IOException | NullPointerException e ) {
			System.out.println("--"+e.getMessage());
		}catch(Exception e) {
			System.out.println("--"+e.getMessage());
		}
		
		System.out.println("----------");
		method(null);
		System.out.println("----------");
		long longWithL = 1000*60*60*24*365L;
		long longWithoutL = 1000*60*60*24*365;
		System.out.println(longWithL);
		System.out.println(longWithoutL);
	}
	public static void method(Object o) {
		System.out.println("Object impl");
	}
	public static void method(String s) {
		System.out.println("String impl");
	}
	
	public static void add(int a, int b){
		int c =a+b;
		System.out.println("int "+c);
	}
	public static void add(Integer a, Integer b){
		Integer c =a+b;
		System.out.println("Integer "+c);
	}
}
