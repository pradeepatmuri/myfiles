package com.java.learn;

public class PalindromeStringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String x= "likil";int i;
		String rev =new StringBuffer(x).reverse().toString() ;
		if(x.equals(rev))
			System.out.println("palindrome");
		else
			System.out.println("not palindrome");
		x= "lirreil";
		boolean b=true;
		int  length = x.length();
		for(i=0;i<length/2;i++)
			if(!(x.charAt(i)== x.charAt(length-1-i)))
			{
				b=false;break;}
		if (b==true)
			System.out.println("palindrome");
		else
			System.out.println("not palindrome");
	}

}
