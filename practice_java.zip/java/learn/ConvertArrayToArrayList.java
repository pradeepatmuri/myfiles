package com.java.learn;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ConvertArrayToArrayList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// converting from Array  to Arraylist
			String[] strArr = {"1","2","3","5"};
			System.out.println("array "+Arrays.toString(strArr));
			
			List<String> strListArray = Arrays.asList(strArr);
			System.out.println("List by using arrays as list "+strListArray);
			
			List<String> strList =new ArrayList<String>();
			Collections.addAll(strList, strArr);
			System.out.println("List bying collection"+strList);
			strArr[0] = "100"; 
			System.out.println("array "+Arrays.toString(strArr));
			System.out.println("List by using arrays as list "+strListArray);
			System.out.println("List bying collection.addall"+strList);
	}

}
