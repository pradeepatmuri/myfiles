package com.java.learn;
public class Parent {

    public String name;
}