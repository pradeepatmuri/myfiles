package com.java.learn;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;


public class ListExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	// Creating collection	
		Collection<String> names = new ArrayList<String>();
	    System.out.printf("Size = %d, Elements = %s%n", names.size(), names);
	    names.add("XML");
	    names.add("HTML");
	    names.add("CSS");
	    System.out.printf("Size   = %d, Elements   = %s%n",
	        names.size(), names);
	    names.remove("CSS");
	    System.out.printf("Size   = %d, Elements   = %s%n",
	        names.size(), names);
	    //names.clear();
	   
	    System.out.println("names"+  names);
	    Collection<String> names1 = new ArrayList<String>();
	    System.out.printf("Size = %d, Elements = %s%n", names1.size(), names1);
	    names1.add("XML");
	    names1.add("HTML");
	    names1.add("CSS");
	    System.out.println("names1"+  names1);
	    System.out.println(names1.containsAll(names));
	    System.out.println(names.containsAll(names1));
	    
	    
	   /* names1.addAll(names);
	    System.out.println("after add all"+ names1);*/
	    
	    names1.retainAll(names);
	    System.out.println("after remove all"+  names1);
	 // creating an Array list
	    ArrayList<String> listStrings = new ArrayList<String>();
	    listStrings.add("One");
	    listStrings.add("Two");
	    listStrings.add("Three");
	    listStrings.add("Four");
	     
	    System.out.println(listStrings);
	 // converting from ArrayList List to String
	    String[] nameString = (String[])listStrings.toArray(new String[listStrings.size()]); 
	    for (int i=0;i<nameString.length;i++)
	    	System.out.println("StringArray"+nameString[i]);
	  // creating an linked list
	    LinkedList<String> listStrings1 = new LinkedList<String>();
	    listStrings1.add("Five");
	    listStrings1.add("Six");
	    listStrings1.add("Seven");
	    listStrings1.add("Eight");
	     
	    System.out.println(listStrings1);
	    
	   
	    System.out.println("Iterator");
	    
	  // displaying the values by using iterator
	    Iterator listIterator = listStrings1.iterator();
	    while(listIterator.hasNext())
	     System.out.println("  "+listIterator.next());
	  // Converting from Linked lIst to to String array
	    
	    System.out.println("Converting from Linked lIst to to String array");
	    String[] nameLinkedList = (String[])listStrings1.toArray(new String[listStrings1.size()]);
	    for (int i=0;i<nameLinkedList.length;i++)
	    	System.out.print(" "+nameLinkedList[i]);
	   
	 // Set example
	    System.out.println("");
	    
	    List<String> listStrings3 = new LinkedList<String>();
	    listStrings3.add("1");
	    listStrings3.add("2");
	    listStrings3.add("3");
	    listStrings3.add("4");
	    System.out.println(listStrings3);
	    
	    for(String stringVar:listStrings3)
	      System.out.print(" "+stringVar);
	    System.out.println("");
	    ListIterator listiterator = listStrings3.listIterator();
	    while(listiterator.hasNext())
	    {   
	    	System.out.println(listiterator.next());
	    }
	    while(listiterator.hasPrevious())
	    {   
	    	String x = (String) listiterator.previous();
	    	System.out.println(x);
	    	if(x.equals("4"))
	    	listiterator.add("5");
	    }
	    System.out.println("--------------");
	    List <Integer> myList= new ArrayList<>();
	    for(int i=0;i<10;i++)
	    	myList.add(i);
	    
	    Iterator<Integer> it = myList.iterator();
	    while(it.hasNext())
	    {
	    	int  x =  it.next();
	    	System.out.println(x);
	    }
	    List<Integer> myList1 = new LinkedList<>(myList);
	    System.out.println(myList1);
	    myList1.forEach(System.out::print);
	    System.out.println();
	    myList1.forEach((Integer i) -> {System.out.print(i);});
	}

}
