package com.java.learn;

public class Student {

	
	String name;
	int rno;
	Student(int rno,String name)
	{
		this.rno=rno;
		this.name=name;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student s1 = new Student(10,"Pradeep");
		Student s2 = new Student(100,"Kanthi");
		System.out.println(s1);
		System.out.println(s2);
	}
	public String toString(){
		//return getClass().getName() +" @ " + Integer.toHexString(hashCode()) ;
		return name +" @ " + hashCode() ;
	}
	
	public int hashCode(){
		return rno;
	}

}